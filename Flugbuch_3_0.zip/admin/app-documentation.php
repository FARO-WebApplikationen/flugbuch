<?php
	require(__DIR__ . '/incCommon.php');

	$GLOBALS['page_title'] = $Translation['app documentation'];
	include(__DIR__ . '/incHeader.php');
	
	include(__DIR__ . '/incFooter.php');
