var FiltersEnabled = 0; // if your not going to use transitions or filters in any of the tips set this to 0
var spacer="&nbsp; &nbsp; &nbsp; ";

// email notifications to admin
notifyAdminNewMembers0Tip=["", spacer+"No email notifications to admin."];
notifyAdminNewMembers1Tip=["", spacer+"Notify admin only when a new member is waiting for approval."];
notifyAdminNewMembers2Tip=["", spacer+"Notify admin for all new sign-ups."];

// visitorSignup
visitorSignup0Tip=["", spacer+"If this option is selected, visitors will not be able to join this group unless the admin manually moves them to this group from the admin area."];
visitorSignup1Tip=["", spacer+"If this option is selected, visitors can join this group but will not be able to sign in unless the admin approves them from the admin area."];
visitorSignup2Tip=["", spacer+"If this option is selected, visitors can join this group and will be able to sign in instantly with no need for admin approval."];

// flugbuch_verein table
flugbuch_verein_addTip=["",spacer+"This option allows all members of the group to add records to the 'Mein Vereinsflugbuch' table. A member who adds a record to the table becomes the 'owner' of that record."];

flugbuch_verein_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Mein Vereinsflugbuch' table."];
flugbuch_verein_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Mein Vereinsflugbuch' table."];
flugbuch_verein_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Mein Vereinsflugbuch' table."];
flugbuch_verein_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Mein Vereinsflugbuch' table."];

flugbuch_verein_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Mein Vereinsflugbuch' table."];
flugbuch_verein_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Mein Vereinsflugbuch' table."];
flugbuch_verein_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Mein Vereinsflugbuch' table."];
flugbuch_verein_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Mein Vereinsflugbuch' table, regardless of their owner."];

flugbuch_verein_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Mein Vereinsflugbuch' table."];
flugbuch_verein_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Mein Vereinsflugbuch' table."];
flugbuch_verein_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Mein Vereinsflugbuch' table."];
flugbuch_verein_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Mein Vereinsflugbuch' table."];

// flugplaetze_oe table
flugplaetze_oe_addTip=["",spacer+"This option allows all members of the group to add records to the 'Flugpl&#228;tze' table. A member who adds a record to the table becomes the 'owner' of that record."];

flugplaetze_oe_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Flugpl&#228;tze' table."];
flugplaetze_oe_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Flugpl&#228;tze' table."];
flugplaetze_oe_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Flugpl&#228;tze' table."];
flugplaetze_oe_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Flugpl&#228;tze' table."];

flugplaetze_oe_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Flugpl&#228;tze' table."];
flugplaetze_oe_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Flugpl&#228;tze' table."];
flugplaetze_oe_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Flugpl&#228;tze' table."];
flugplaetze_oe_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Flugpl&#228;tze' table, regardless of their owner."];

flugplaetze_oe_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Flugpl&#228;tze' table."];
flugplaetze_oe_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Flugpl&#228;tze' table."];
flugplaetze_oe_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Flugpl&#228;tze' table."];
flugplaetze_oe_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Flugpl&#228;tze' table."];

// mitgliederverwaltung table
mitgliederverwaltung_addTip=["",spacer+"This option allows all members of the group to add records to the 'Mitgliederverwaltung' table. A member who adds a record to the table becomes the 'owner' of that record."];

mitgliederverwaltung_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Mitgliederverwaltung' table."];
mitgliederverwaltung_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Mitgliederverwaltung' table."];
mitgliederverwaltung_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Mitgliederverwaltung' table."];
mitgliederverwaltung_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Mitgliederverwaltung' table."];

mitgliederverwaltung_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Mitgliederverwaltung' table."];
mitgliederverwaltung_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Mitgliederverwaltung' table."];
mitgliederverwaltung_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Mitgliederverwaltung' table."];
mitgliederverwaltung_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Mitgliederverwaltung' table, regardless of their owner."];

mitgliederverwaltung_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Mitgliederverwaltung' table."];
mitgliederverwaltung_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Mitgliederverwaltung' table."];
mitgliederverwaltung_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Mitgliederverwaltung' table."];
mitgliederverwaltung_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Mitgliederverwaltung' table."];

// vereinsunterlagen table
vereinsunterlagen_addTip=["",spacer+"This option allows all members of the group to add records to the 'Vereinsunterlagen' table. A member who adds a record to the table becomes the 'owner' of that record."];

vereinsunterlagen_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Vereinsunterlagen' table."];
vereinsunterlagen_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Vereinsunterlagen' table."];
vereinsunterlagen_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Vereinsunterlagen' table."];
vereinsunterlagen_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Vereinsunterlagen' table."];

vereinsunterlagen_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Vereinsunterlagen' table."];
vereinsunterlagen_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Vereinsunterlagen' table."];
vereinsunterlagen_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Vereinsunterlagen' table."];
vereinsunterlagen_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Vereinsunterlagen' table, regardless of their owner."];

vereinsunterlagen_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Vereinsunterlagen' table."];
vereinsunterlagen_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Vereinsunterlagen' table."];
vereinsunterlagen_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Vereinsunterlagen' table."];
vereinsunterlagen_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Vereinsunterlagen' table."];

// betriebsdokumentation table
betriebsdokumentation_addTip=["",spacer+"This option allows all members of the group to add records to the 'Betriebsdokumentation' table. A member who adds a record to the table becomes the 'owner' of that record."];

betriebsdokumentation_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Betriebsdokumentation' table."];
betriebsdokumentation_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Betriebsdokumentation' table."];
betriebsdokumentation_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Betriebsdokumentation' table."];
betriebsdokumentation_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Betriebsdokumentation' table."];

betriebsdokumentation_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Betriebsdokumentation' table."];
betriebsdokumentation_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Betriebsdokumentation' table."];
betriebsdokumentation_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Betriebsdokumentation' table."];
betriebsdokumentation_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Betriebsdokumentation' table, regardless of their owner."];

betriebsdokumentation_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Betriebsdokumentation' table."];
betriebsdokumentation_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Betriebsdokumentation' table."];
betriebsdokumentation_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Betriebsdokumentation' table."];
betriebsdokumentation_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Betriebsdokumentation' table."];

// inventar table
inventar_addTip=["",spacer+"This option allows all members of the group to add records to the 'Inventar des Vereins' table. A member who adds a record to the table becomes the 'owner' of that record."];

inventar_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Inventar des Vereins' table."];
inventar_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Inventar des Vereins' table."];
inventar_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Inventar des Vereins' table."];
inventar_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Inventar des Vereins' table."];

inventar_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Inventar des Vereins' table."];
inventar_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Inventar des Vereins' table."];
inventar_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Inventar des Vereins' table."];
inventar_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Inventar des Vereins' table, regardless of their owner."];

inventar_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Inventar des Vereins' table."];
inventar_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Inventar des Vereins' table."];
inventar_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Inventar des Vereins' table."];
inventar_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Inventar des Vereins' table."];

// dokumente table
dokumente_addTip=["",spacer+"This option allows all members of the group to add records to the 'Meine Dokumente' table. A member who adds a record to the table becomes the 'owner' of that record."];

dokumente_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Meine Dokumente' table."];
dokumente_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Meine Dokumente' table."];
dokumente_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Meine Dokumente' table."];
dokumente_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Meine Dokumente' table."];

dokumente_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Meine Dokumente' table."];
dokumente_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Meine Dokumente' table."];
dokumente_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Meine Dokumente' table."];
dokumente_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Meine Dokumente' table, regardless of their owner."];

dokumente_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Meine Dokumente' table."];
dokumente_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Meine Dokumente' table."];
dokumente_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Meine Dokumente' table."];
dokumente_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Meine Dokumente' table."];

// modelle table
modelle_addTip=["",spacer+"This option allows all members of the group to add records to the 'Meine Modelle' table. A member who adds a record to the table becomes the 'owner' of that record."];

modelle_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Meine Modelle' table."];
modelle_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Meine Modelle' table."];
modelle_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Meine Modelle' table."];
modelle_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Meine Modelle' table."];

modelle_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Meine Modelle' table."];
modelle_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Meine Modelle' table."];
modelle_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Meine Modelle' table."];
modelle_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Meine Modelle' table, regardless of their owner."];

modelle_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Meine Modelle' table."];
modelle_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Meine Modelle' table."];
modelle_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Meine Modelle' table."];
modelle_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Meine Modelle' table."];

// checklisten table
checklisten_addTip=["",spacer+"This option allows all members of the group to add records to the 'Meine Checklisten' table. A member who adds a record to the table becomes the 'owner' of that record."];

checklisten_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Meine Checklisten' table."];
checklisten_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Meine Checklisten' table."];
checklisten_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Meine Checklisten' table."];
checklisten_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Meine Checklisten' table."];

checklisten_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Meine Checklisten' table."];
checklisten_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Meine Checklisten' table."];
checklisten_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Meine Checklisten' table."];
checklisten_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Meine Checklisten' table, regardless of their owner."];

checklisten_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Meine Checklisten' table."];
checklisten_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Meine Checklisten' table."];
checklisten_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Meine Checklisten' table."];
checklisten_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Meine Checklisten' table."];

// akkus table
akkus_addTip=["",spacer+"This option allows all members of the group to add records to the 'Meine Akkus' table. A member who adds a record to the table becomes the 'owner' of that record."];

akkus_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Meine Akkus' table."];
akkus_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Meine Akkus' table."];
akkus_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Meine Akkus' table."];
akkus_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Meine Akkus' table."];

akkus_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Meine Akkus' table."];
akkus_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Meine Akkus' table."];
akkus_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Meine Akkus' table."];
akkus_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Meine Akkus' table, regardless of their owner."];

akkus_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Meine Akkus' table."];
akkus_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Meine Akkus' table."];
akkus_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Meine Akkus' table."];
akkus_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Meine Akkus' table."];

// modellbetriebskartei table
modellbetriebskartei_addTip=["",spacer+"This option allows all members of the group to add records to the 'Betriebszeiten Modelle' table. A member who adds a record to the table becomes the 'owner' of that record."];

modellbetriebskartei_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Betriebszeiten Modelle' table."];
modellbetriebskartei_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Betriebszeiten Modelle' table."];
modellbetriebskartei_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Betriebszeiten Modelle' table."];
modellbetriebskartei_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Betriebszeiten Modelle' table."];

modellbetriebskartei_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Betriebszeiten Modelle' table."];
modellbetriebskartei_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Betriebszeiten Modelle' table."];
modellbetriebskartei_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Betriebszeiten Modelle' table."];
modellbetriebskartei_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Betriebszeiten Modelle' table, regardless of their owner."];

modellbetriebskartei_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Betriebszeiten Modelle' table."];
modellbetriebskartei_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Betriebszeiten Modelle' table."];
modellbetriebskartei_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Betriebszeiten Modelle' table."];
modellbetriebskartei_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Betriebszeiten Modelle' table."];

// akkubetriebskartei table
akkubetriebskartei_addTip=["",spacer+"This option allows all members of the group to add records to the 'Betriebszeiten Akkus' table. A member who adds a record to the table becomes the 'owner' of that record."];

akkubetriebskartei_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Betriebszeiten Akkus' table."];
akkubetriebskartei_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Betriebszeiten Akkus' table."];
akkubetriebskartei_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Betriebszeiten Akkus' table."];
akkubetriebskartei_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Betriebszeiten Akkus' table."];

akkubetriebskartei_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Betriebszeiten Akkus' table."];
akkubetriebskartei_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Betriebszeiten Akkus' table."];
akkubetriebskartei_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Betriebszeiten Akkus' table."];
akkubetriebskartei_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Betriebszeiten Akkus' table, regardless of their owner."];

akkubetriebskartei_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Betriebszeiten Akkus' table."];
akkubetriebskartei_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Betriebszeiten Akkus' table."];
akkubetriebskartei_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Betriebszeiten Akkus' table."];
akkubetriebskartei_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Betriebszeiten Akkus' table."];

// ticketsystem table
ticketsystem_addTip=["",spacer+"This option allows all members of the group to add records to the 'Support-Ticketsystem' table. A member who adds a record to the table becomes the 'owner' of that record."];

ticketsystem_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Support-Ticketsystem' table."];
ticketsystem_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Support-Ticketsystem' table."];
ticketsystem_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Support-Ticketsystem' table."];
ticketsystem_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Support-Ticketsystem' table."];

ticketsystem_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Support-Ticketsystem' table."];
ticketsystem_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Support-Ticketsystem' table."];
ticketsystem_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Support-Ticketsystem' table."];
ticketsystem_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Support-Ticketsystem' table, regardless of their owner."];

ticketsystem_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Support-Ticketsystem' table."];
ticketsystem_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Support-Ticketsystem' table."];
ticketsystem_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Support-Ticketsystem' table."];
ticketsystem_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Support-Ticketsystem' table."];

/*
	Style syntax:
	-------------
	[TitleColor,TextColor,TitleBgColor,TextBgColor,TitleBgImag,TextBgImag,TitleTextAlign,
	TextTextAlign,TitleFontFace,TextFontFace, TipPosition, StickyStyle, TitleFontSize,
	TextFontSize, Width, Height, BorderSize, PadTextArea, CoordinateX , CoordinateY,
	TransitionNumber, TransitionDuration, TransparencyLevel ,ShadowType, ShadowColor]

*/

toolTipStyle=["white","#00008B","#000099","#E6E6FA","","images/helpBg.gif","","","","\"Trebuchet MS\", sans-serif","","","","3",400,"",1,2,10,10,51,1,0,"",""];

applyCssFilter();
