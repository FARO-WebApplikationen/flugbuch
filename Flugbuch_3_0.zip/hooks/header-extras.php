<script src="hooks/AppGiniHelper.min.js"></script>

<script>
	new AppGiniCommon()
	.setTitle("Modellflugsport - Flugbuch")
	.setIcon("plane")
	.autoDirect();
</script>

<!--
<style>
	body{
	background: url("images/hintergrund.jpg") no-repeat fixed center center / cover;
	}
</style>
-->

<script>
var navbar = AppGiniHelper.common.getNavbar();

var dropdown = navbar.addDropdown("Info", "question-sign", NavPosition.Right);

// dropdown.addDivider("zum Flugbuch");
dropdown.addLink("Schulungsvideo Anwender", "https://youtu.be/1L33JbUNr3g", "_help", "_blank");
dropdown.addLink("Schulungsvideo Administrator", "https://youtu.be/LumDVXn5TR8", "_help", "_blank");
dropdown.addDivider();
dropdown.addLink("Zukunft Modellflugsport", "https://www.modellflugsport.at/", "_help", "_blank");
dropdown.addLink("prop.at", "https://www.prop.at/", "_help", "_blank");
dropdown.addLink("Datenschutz", "https://aeroclub.at/?id=1496", "_help", "_blank");
dropdown.addDivider();
dropdown.addLink("Lizenz", "lizenz.html", "_help", "_self");
</script>






<!-- ******************************************************************************************************
     **************************** ab hier bitte keine Veränderungen vornehmen *****************************
	 ******************************************************************************************************
-->

<?php 
    $page_name = basename($_SERVER['PHP_SELF']);
    if ($page_name == 'membership_profile.php') {
?>

<script>
$j(function() {
	$j('#email').prop('readonly', false);
	$j('#custom1').prop('readonly', true);
	$j('#custom2').prop('readonly', false);
	$j('#custom3').prop('readonly', false);
	$j('#custom4').prop('readonly', false);
})
</script>

<?php
    }
?>

<script>
	new AppGiniCommon().navbar.fix();
</script>

<?php
	include_once(__DIR__ . '/../plugins/messages/app-resources/icon.php');
		