var dv = AppGiniHelper.DV;
// dv.getField("pilot").size(350);
// dv.getField("anzahl_fluege").size(150);
// dv.getField("anzahl_fluege_120").size(150);
// dv.getField("beginn").size(150);
// dv.getField("ende").size(150);

var f1 = dv.addFooter();
f1.append("Österreichischer AeroClub - Flugbuch");

AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();