var dv = AppGiniHelper.DV;
// dv.getField("checklistennummer").size(250);
// dv.getField("hersteller").size(400);
// dv.getField("modelltyp").size(400);

var f1 = dv.addFooter();
f1.append("Österreichischer AeroClub - Flugbuch");

AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();
