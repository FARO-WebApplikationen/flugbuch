var dv = AppGiniHelper.DV;
// dv.getField("nr").size(200);

var f1 = dv.addFooter();
f1.append("Österreichischer AeroClub - Flugbuch");

AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();

// populate curent date time for NEW record
$j(function () {
    // check if data (record) exist or not
    if ($j('#gueltig_von').val()) return;
    // populate the current date (using moment.js)
    $j('#gueltig_von').val(moment().format('DD.MM.YYYY'));	
    // check if data (record) exist or not
    if ($j('#gueltig_bis').val()) return;
    // populate the current date (using moment.js)
    $j('#gueltig_bis').val(moment().format('DD.MM.YYYY'));

});