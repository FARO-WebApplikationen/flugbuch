if (!$j("#gastpilot").is(':checked'))  {
	$j("#name_gastpilot").parents('.form-group').hide();
	$j("#reg_nr").parents('.form-group').hide();
}	

$j("#gastpilot").on('change', function () {  
// if you want to show only the label
if ($j(this).is(':checked')) { 
	$j("label[for='name_gastpilot']").parent('.form-group').show();
	$j("label[for='reg_nr']").parent('.form-group').show();
}
else {
	$j("label[for='name_gastpilot']").parent('.form-group').hide();
	$j("label[for='reg_nr']").parent('.form-group').hide();
}
});  	
	
var dv = AppGiniHelper.DV;
dv.getField("pilot").size(350);
dv.getField("anzahl_fluege").size(150);
dv.getField("anzahl_fluege_120").size(150);
dv.getField("beginn").size(150);
dv.getField("ende").size(150);

var f1 = dv.addFooter();
f1.append("Österreichischer AeroClub - Flugbuch");

AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();
AppGiniFields(["pilot"]).readonly();

// populate curent date time for NEW record
$j(function () {
    // check if data (record) exist or not
    if ($j('#datum').val()) return;
    // populate the current date (using moment.js)
    $j('#datum').val(moment().format('DD.MM.YYYY'));	
	// check if data (record) exist or not
    if ($j('#beginn').val()) return;
    // populate the current date time (using moment.js)
    $j('#beginn').val(moment().format('H:mm'));
	// check if data (record) exist or not
	if ($j('#ende').val()) return;
	// check if data (record) exist or not
	$j('#ende').val(moment().add(180, 'minutes').format('H:mm'));

});