var dv = AppGiniHelper.DV;
dv.getField("nr").size(200);
dv.getField("anrede").size(200);
dv.getField("titel_vor").size(400);
dv.getField("titel_nach").size(400);
dv.getField("vorname").size(400);
dv.getField("nachname").size(400);
dv.getField("strasse").size(400);
dv.getField("plz").size(200);
dv.getField("ort").size(400);
dv.getField("nummer").size(200);
dv.getField("telefon").size(400);
dv.getField("mobiltelefon").size(400);
dv.getField("registriernummer").size(400);
dv.getField("kompetenznachweis").size(400);
dv.getField("beitrittsjahr").size(150);

var f1 = dv.addFooter();
f1.append("Österreichischer AeroClub - Flugbuch");

AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();

// populate curent date time for NEW record
$j(function () {
    
	// check if data (record) exist or not
    if ($j('#datum').val()) return;
    // populate the current date (using moment.js)
    $j('#datum').val(moment().format('DD.MM.YYYY'));	
	
	// check if data (record) exist or not
    if ($j('#eintrittsdatum').val()) return;
    // populate the current date time (using moment.js)
    $j('#eintrittsdatum').val(moment().format('DD.MM.YYYY'));
	
	// check if data (record) exist or not
    if ($j('#geburtsdatum').val()) return;
    // populate the current date time (using moment.js)
    $j('#geburtsdatum').val(moment().format('DD.MM.YYYY'));
	
	// check if data (record) exist or not
    if ($j('#beginn_mitglied').val()) return;
    // populate the current date time (using moment.js)
    $j('#beginn_mitglied').val(moment().format('DD.MM.YYYY'));
	
	// check if data (record) exist or not
    if ($j('#reg_gueltig').val()) return;
    // populate the current date time (using moment.js)
    $j('#reg_gueltig').val(moment().format('DD.MM.YYYY'));
});