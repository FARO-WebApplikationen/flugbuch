<?php
	$script_name = basename($_SERVER['PHP_SELF']);
	if($script_name == 'index.php' && isset($_GET['signIn'])){
		?>
		<style>
			body{
				background: url("images/hintergrund_flugbuch.jpg") no-repeat fixed center center / cover;
			}
		</style>
		
		<div class="alert alert-success" id="benefits">
			<img src="./images/logo.png" alt="ÖAeC Logo">
			<br><br>
			<h4><b>Dieser Text kann in der Datei footer-extras.php<br>
			im Verzeichnis hooks angepasst werden</b></h4>
			</a>
		</div>
		
		<script>
			$j(function(){
				$j('#benefits').appendTo('#login_splash');
			})
		</script>

		
<?php
	}
?>

<!-- copyright notice -->
	<div style="height: 60px;" class="hidden-print"></div>
		<nav class="navbar navbar-default navbar-fixed-bottom" role="navigation">
			<p class="navbar-text"><small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&copy; 2022 | CF | Version 3.0</a></small></p>
		</nav>
	</div>