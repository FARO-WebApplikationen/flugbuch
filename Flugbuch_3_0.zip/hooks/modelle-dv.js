var dv = AppGiniHelper.DV;
dv.getField("inventarnummer").size(250);
dv.getField("hersteller").size(400);
dv.getField("modellname").size(400);
dv.getField("gewicht").size(250);
dv.getField("kaufpreis").size(250);

var f1 = dv.addFooter();
f1.append("Österreichischer AeroClub - Flugbuch");

AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();

// populate curent date time for NEW record
$j(function () {
    // check if data (record) exist or not
    if ($j('#kaufdatum').val()) return;
    // populate the current date (using moment.js)
    $j('#kaufdatum').val(moment().format('DD.MM.YYYY'));	
    // check if data (record) exist or not
    if ($j('#erstflugdatum').val()) return;
    // populate the current date (using moment.js)
    $j('#erstflugdatum').val(moment().format('DD.MM.YYYY'));

});