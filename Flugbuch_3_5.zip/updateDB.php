<?php
	// check this file's MD5 to make sure it wasn't called before
	$tenantId = Authentication::tenantIdPadded();
	$setupHash = __DIR__ . "/setup{$tenantId}.md5";

	$prevMD5 = @file_get_contents($setupHash);
	$thisMD5 = md5_file(__FILE__);

	// check if this setup file already run
	if($thisMD5 != $prevMD5) {
		// set up tables
		setupTable(
			'flugbuch_verein', " 
			CREATE TABLE IF NOT EXISTS `flugbuch_verein` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`datum` DATETIME NULL,
				`beginn` TIME NULL,
				`ende` TIME NULL,
				`pilot` VARCHAR(80) NULL,
				`anzahl_fluege` INT NULL,
				`anzahl_fluege_120` INT NULL,
				`max_flughoehe` INT NULL,
				`flugplatz` INT UNSIGNED NULL,
				`luftraumbeobachter` VARCHAR(80) NULL,
				`modell` INT UNSIGNED NULL,
				`name_gastpilot` VARCHAR(80) NULL,
				`reg_nr_gastpilot` VARCHAR(40) NULL,
				`name_vereinsmitglied` VARCHAR(80) NULL,
				`reg_nr_vereinsmitglied` VARCHAR(40) NULL,
				`besonderheiten` TEXT NULL,
				`datei` VARCHAR(40) NULL,
				`datei_1` VARCHAR(40) NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` DATETIME NULL,
				`geaendert_von` VARCHAR(60) NULL,
				`geaendert` DATETIME NULL
			) CHARSET utf8"
		);
		setupIndexes('flugbuch_verein', ['flugplatz','modell',]);

		setupTable(
			'betriebsaufzeichnung', " 
			CREATE TABLE IF NOT EXISTS `betriebsaufzeichnung` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`datum` DATETIME NULL,
				`beginn` TIME NULL,
				`ende` TIME NULL,
				`pilot` VARCHAR(80) NULL,
				`anzahl_fluege` INT NULL,
				`anzahl_fluege_120` INT NULL,
				`luftraumbeobachter` VARCHAR(80) NULL,
				`reg_nr` VARCHAR(40) NULL,
				`unterkunft` VARCHAR(60) NULL,
				`bestaetigung` VARCHAR(80) NULL DEFAULT 'Angef&#252;hrte Dokumente werden mit meiner Unterschrift best&#228;tigt !',
				`besonderheiten` TEXT NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` DATETIME NULL,
				`geaendert_von` VARCHAR(60) NULL,
				`geaendert` DATETIME NULL,
				`unterschrift` TEXT NOT NULL
			) CHARSET utf8"
		);

		setupTable(
			'flugplaetze_oe', " 
			CREATE TABLE IF NOT EXISTS `flugplaetze_oe` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`flugplatznummer` VARCHAR(15) NULL,
				UNIQUE `flugplatznummer_unique` (`flugplatznummer`),
				`artikel_16` VARCHAR(10) NULL DEFAULT 'Ja',
				`artikel16` VARCHAR(40) NULL,
				`mfbo` VARCHAR(40) NULL,
				`richtlinie` VARCHAR(40) NULL,
				`flugplatzordnung` VARCHAR(40) NULL,
				`verhaltensregeln` VARCHAR(40) NULL,
				`sonstige_datei` VARCHAR(40) NULL,
				`vereinsname` VARCHAR(60) NULL,
				UNIQUE `vereinsname_unique` (`vereinsname`),
				`bundesland` VARCHAR(40) NULL,
				`webseite` VARCHAR(150) NULL,
				`telefon` VARCHAR(40) NULL,
				`vorname` VARCHAR(40) NULL,
				`nachname` VARCHAR(40) NULL,
				`email` VARCHAR(80) NULL,
				`zvr` VARCHAR(40) NULL,
				`flughoehe` VARCHAR(10) NULL,
				`mtom` VARCHAR(10) NULL,
				`google_map` TEXT NULL,
				`open_street_map` TEXT NULL,
				`acg_map` TEXT NULL,
				`flugbereich` VARCHAR(40) NULL,
				`bild1` VARCHAR(40) NULL,
				`bild2` VARCHAR(40) NULL,
				`bild3` VARCHAR(40) NULL,
				`kontrollzone` VARCHAR(10) NULL,
				`besonderheit` VARCHAR(40) NULL,
				`beschreibung` TEXT NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` VARCHAR(40) NULL,
				`geaendert_von` VARCHAR(40) NULL,
				`geaendert` VARCHAR(40) NULL
			) CHARSET utf8"
		);

		setupTable(
			'bescheiddokumente', " 
			CREATE TABLE IF NOT EXISTS `bescheiddokumente` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`bezeichnung` VARCHAR(40) NULL,
				`version` VARCHAR(10) NULL,
				`gueltigkeit` DATETIME NULL,
				`datei` VARCHAR(40) NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` VARCHAR(40) NULL,
				`geaendert_von` VARCHAR(40) NULL,
				`geaendert` VARCHAR(40) NULL
			) CHARSET utf8"
		);

		setupTable(
			'mitgliederverwaltung', " 
			CREATE TABLE IF NOT EXISTS `mitgliederverwaltung` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`datum` DATETIME NULL,
				`nr` VARCHAR(10) NULL,
				`anrede` VARCHAR(10) NULL,
				`titel_vor` VARCHAR(40) NULL,
				`titel_nach` VARCHAR(40) NULL,
				`vorname` VARCHAR(40) NULL,
				`nachname` VARCHAR(40) NULL,
				`strasse` VARCHAR(40) NULL,
				`nummer` VARCHAR(40) NULL,
				`plz` VARCHAR(40) NULL,
				`ort` VARCHAR(40) NULL,
				`geburtsdatum` DATETIME NULL,
				`email` VARCHAR(80) NULL,
				`telefon` VARCHAR(40) NULL,
				`mobiltelefon` VARCHAR(40) NULL,
				`beitrittsjahr` VARCHAR(4) NULL,
				`oeaec_nr` VARCHAR(50) NULL,
				`status` VARCHAR(60) NULL,
				`registriernummer` VARCHAR(40) NULL,
				`reg_gueltig` DATETIME NULL,
				`kompetenznachweis` VARCHAR(40) NULL,
				`kom_gueltig` DATETIME NULL,
				`pruefungen` VARCHAR(100) NULL,
				`funktionen` VARCHAR(60) NULL,
				`beschreibung` TEXT NULL,
				`bild` VARCHAR(40) NULL,
				`datei` VARCHAR(40) NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` DATETIME NULL,
				`geaendert_von` VARCHAR(60) NULL,
				`geaendert` DATETIME NULL
			) CHARSET utf8"
		);

		setupTable(
			'vereinsunterlagen', " 
			CREATE TABLE IF NOT EXISTS `vereinsunterlagen` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`datum` DATETIME NULL,
				`nr` VARCHAR(10) NULL,
				`titel` VARCHAR(40) NULL,
				`beschreibung` TEXT NULL,
				`datei` VARCHAR(40) NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` DATETIME NULL,
				`geaendert_von` VARCHAR(60) NULL,
				`geaendert` DATETIME NULL
			) CHARSET utf8"
		);

		setupTable(
			'betriebsdoku', " 
			CREATE TABLE IF NOT EXISTS `betriebsdoku` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`datum` DATETIME NULL,
				`nr` VARCHAR(10) NULL,
				`titel` VARCHAR(40) NULL,
				`beschreibung` TEXT NULL,
				`datei` VARCHAR(40) NULL,
				`bild1` VARCHAR(40) NULL,
				`bild2` VARCHAR(40) NULL,
				`bild3` VARCHAR(40) NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` DATETIME NULL,
				`geaendert_von` VARCHAR(60) NULL,
				`geaendert` DATETIME NULL
			) CHARSET utf8"
		);

		setupTable(
			'inventar', " 
			CREATE TABLE IF NOT EXISTS `inventar` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`datum` DATETIME NULL,
				`nr` VARCHAR(10) NULL,
				`titel` VARCHAR(40) NULL,
				`beschreibung` TEXT NULL,
				`datei` VARCHAR(40) NULL,
				`anleitung` VARCHAR(40) NULL,
				`bild_1` VARCHAR(40) NULL,
				`bild_2` VARCHAR(40) NULL,
				`bild_3` VARCHAR(40) NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` DATETIME NULL,
				`geaendert_von` VARCHAR(60) NULL,
				`geaendert` DATETIME NULL
			) CHARSET utf8"
		);

		setupTable(
			'dokumente', " 
			CREATE TABLE IF NOT EXISTS `dokumente` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`beschreibung` VARCHAR(40) NULL,
				`file` VARCHAR(40) NULL,
				`gueltig_von` DATETIME NULL,
				`gueltig_bis` DATETIME NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` VARCHAR(40) NULL,
				`geaendert_von` VARCHAR(40) NULL,
				`geaendert` VARCHAR(40) NULL
			) CHARSET utf8"
		);

		setupTable(
			'modelle', " 
			CREATE TABLE IF NOT EXISTS `modelle` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`inventarnummer` VARCHAR(40) NULL,
				`modellname` VARCHAR(60) NULL,
				UNIQUE `modellname_unique` (`modellname`),
				`hersteller` VARCHAR(60) NULL,
				`modelltyp` VARCHAR(40) NOT NULL,
				`beschreibung` TEXT NULL,
				`kaufdatum` DATETIME NULL,
				`erstflugdatum` DATETIME NULL,
				`gewicht` VARCHAR(40) NULL,
				`kaufpreis` VARCHAR(40) NULL,
				`technische_ausstattung` TEXT NULL,
				`bild1` VARCHAR(40) NULL,
				`bild2` VARCHAR(40) NULL,
				`bild3` VARCHAR(40) NULL,
				`datenblatt` VARCHAR(40) NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` VARCHAR(40) NULL,
				`geaendert_von` VARCHAR(40) NULL,
				`geaendert` VARCHAR(40) NULL
			) CHARSET utf8"
		);

		setupTable(
			'checklisten', " 
			CREATE TABLE IF NOT EXISTS `checklisten` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`checklistennummer` VARCHAR(40) NULL,
				`gewicht` TEXT NOT NULL,
				`modellname` INT UNSIGNED NULL,
				`hersteller` INT UNSIGNED NULL,
				`modelltyp` INT UNSIGNED NULL,
				`datei1` VARCHAR(40) NULL,
				`datei2` VARCHAR(40) NULL,
				`bild1` VARCHAR(40) NULL,
				`bild2` VARCHAR(40) NULL,
				`bild3` VARCHAR(40) NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` VARCHAR(40) NULL,
				`geaendert_von` VARCHAR(40) NULL,
				`geaendert` VARCHAR(40) NULL
			) CHARSET utf8"
		);
		setupIndexes('checklisten', ['modellname',]);

		setupTable(
			'akkus', " 
			CREATE TABLE IF NOT EXISTS `akkus` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`inventarnummer` VARCHAR(40) NULL,
				`kaufdatum` DATETIME NULL,
				`kaufpreis` VARCHAR(10) NULL,
				`marke` VARCHAR(40) NULL,
				`kapazitaet` VARCHAR(40) NULL,
				`zellenanzahl` VARCHAR(40) NULL,
				`technische_daten` VARCHAR(40) NULL,
				`anmerkungen` TEXT NULL,
				`datei1` VARCHAR(40) NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` VARCHAR(40) NULL,
				`geaendert_von` VARCHAR(40) NULL,
				`geaendert` VARCHAR(40) NULL
			) CHARSET utf8"
		);

		setupTable(
			'modellbetriebszeiten', " 
			CREATE TABLE IF NOT EXISTS `modellbetriebszeiten` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`datum` DATETIME NULL,
				`modellname` INT UNSIGNED NULL,
				`betriebszeit_min` DECIMAL(10,0) NULL,
				`betriebszeit_std` DECIMAL(10,2) NULL,
				`defekte` TEXT NULL,
				`anmerkung` TEXT NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` VARCHAR(40) NULL,
				`geaendert_von` VARCHAR(40) NULL,
				`geaendert` VARCHAR(40) NULL
			) CHARSET utf8"
		);
		setupIndexes('modellbetriebszeiten', ['modellname',]);

		setupTable(
			'akkubetriebszeiten', " 
			CREATE TABLE IF NOT EXISTS `akkubetriebszeiten` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`inventarnummer` INT UNSIGNED NULL,
				`kaufdatum` INT UNSIGNED NULL,
				`marke` INT UNSIGNED NULL,
				`kapazitaet` INT UNSIGNED NULL,
				`zellenanzahl` INT UNSIGNED NULL,
				`datum` DATETIME NULL,
				`ladung` VARCHAR(40) NULL,
				`bemerkung` TEXT NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` VARCHAR(40) NULL,
				`geaendert_von` VARCHAR(40) NULL,
				`geaendert` VARCHAR(40) NULL
			) CHARSET utf8"
		);
		setupIndexes('akkubetriebszeiten', ['inventarnummer',]);

		setupTable(
			'ticketsystem', " 
			CREATE TABLE IF NOT EXISTS `ticketsystem` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`bereich` VARCHAR(40) NOT NULL,
				`art_meldung` VARCHAR(40) NOT NULL,
				`meldungstext` TEXT NULL,
				`bearbeitungstext` TEXT NULL,
				`file` VARCHAR(40) NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` VARCHAR(40) NULL,
				`geaendert_von` VARCHAR(40) NULL,
				`geaendert` VARCHAR(40) NULL,
				`status` VARCHAR(40) NOT NULL
			) CHARSET utf8"
		);

		setupTable(
			'schaden', " 
			CREATE TABLE IF NOT EXISTS `schaden` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`art` VARCHAR(40) NOT NULL,
				`meldungstext` TEXT NULL,
				`bearbeitungstext` TEXT NULL,
				`file_01` VARCHAR(40) NULL,
				`file_02` VARCHAR(40) NULL,
				`file_03` VARCHAR(40) NULL,
				`erfasser` VARCHAR(40) NULL,
				`erfasst` VARCHAR(40) NULL,
				`geaendert_von` VARCHAR(40) NULL,
				`geaendert` VARCHAR(40) NULL,
				`status` VARCHAR(40) NOT NULL
			) CHARSET utf8"
		);



		// save MD5
		@file_put_contents($setupHash, $thisMD5);
	}


	function setupIndexes($tableName, $arrFields) {
		if(!is_array($arrFields) || !count($arrFields)) return false;

		foreach($arrFields as $fieldName) {
			if(!$res = @db_query("SHOW COLUMNS FROM `$tableName` like '$fieldName'")) continue;
			if(!$row = @db_fetch_assoc($res)) continue;
			if($row['Key']) continue;

			@db_query("ALTER TABLE `$tableName` ADD INDEX `$fieldName` (`$fieldName`)");
		}
	}


	function setupTable($tableName, $createSQL = '', $arrAlter = '') {
		global $Translation;
		$oldTableName = '';
		ob_start();

		echo '<div style="padding: 5px; border-bottom:solid 1px silver; font-family: verdana, arial; font-size: 10px;">';

		// is there a table rename query?
		if(is_array($arrAlter)) {
			$matches = [];
			if(preg_match("/ALTER TABLE `(.*)` RENAME `$tableName`/i", $arrAlter[0], $matches)) {
				$oldTableName = $matches[1];
			}
		}

		if($res = @db_query("SELECT COUNT(1) FROM `$tableName`")) { // table already exists
			if($row = @db_fetch_array($res)) {
				echo str_replace(['<TableName>', '<NumRecords>'], [$tableName, $row[0]], $Translation['table exists']);
				if(is_array($arrAlter)) {
					echo '<br>';
					foreach($arrAlter as $alter) {
						if($alter != '') {
							echo "$alter ... ";
							if(!@db_query($alter)) {
								echo '<span class="label label-danger">' . $Translation['failed'] . '</span>';
								echo '<div class="text-danger">' . $Translation['mysql said'] . ' ' . db_error(db_link()) . '</div>';
							} else {
								echo '<span class="label label-success">' . $Translation['ok'] . '</span>';
							}
						}
					}
				} else {
					echo $Translation['table uptodate'];
				}
			} else {
				echo str_replace('<TableName>', $tableName, $Translation['couldnt count']);
			}
		} else { // given tableName doesn't exist

			if($oldTableName != '') { // if we have a table rename query
				if($ro = @db_query("SELECT COUNT(1) FROM `$oldTableName`")) { // if old table exists, rename it.
					$renameQuery = array_shift($arrAlter); // get and remove rename query

					echo "$renameQuery ... ";
					if(!@db_query($renameQuery)) {
						echo '<span class="label label-danger">' . $Translation['failed'] . '</span>';
						echo '<div class="text-danger">' . $Translation['mysql said'] . ' ' . db_error(db_link()) . '</div>';
					} else {
						echo '<span class="label label-success">' . $Translation['ok'] . '</span>';
					}

					if(is_array($arrAlter)) setupTable($tableName, $createSQL, false, $arrAlter); // execute Alter queries on renamed table ...
				} else { // if old tableName doesn't exist (nor the new one since we're here), then just create the table.
					setupTable($tableName, $createSQL, false); // no Alter queries passed ...
				}
			} else { // tableName doesn't exist and no rename, so just create the table
				echo str_replace("<TableName>", $tableName, $Translation["creating table"]);
				if(!@db_query($createSQL)) {
					echo '<span class="label label-danger">' . $Translation['failed'] . '</span>';
					echo '<div class="text-danger">' . $Translation['mysql said'] . db_error(db_link()) . '</div>';

					// create table with a dummy field
					@db_query("CREATE TABLE IF NOT EXISTS `$tableName` (`_dummy_deletable_field` TINYINT)");
				} else {
					echo '<span class="label label-success">' . $Translation['ok'] . '</span>';
				}
			}

			// set Admin group permissions for newly created table if membership_grouppermissions exists
			if($ro = @db_query("SELECT COUNT(1) FROM `membership_grouppermissions`")) {
				// get Admins group id
				$ro = @db_query("SELECT `groupID` FROM `membership_groups` WHERE `name`='Admins'");
				if($ro) {
					$adminGroupID = intval(db_fetch_row($ro)[0]);
					if($adminGroupID) @db_query("INSERT IGNORE INTO `membership_grouppermissions` SET
						`groupID`='$adminGroupID',
						`tableName`='$tableName',
						`allowInsert`=1, `allowView`=1, `allowEdit`=1, `allowDelete`=1
					");
				}
			}
		}

		echo '</div>';

		$out = ob_get_clean();
		if(defined('APPGINI_SETUP') && APPGINI_SETUP) echo $out;
	}
