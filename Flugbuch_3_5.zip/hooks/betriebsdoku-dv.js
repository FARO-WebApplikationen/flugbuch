var f1 = dv.addFooter();
f1.append("CF - Flugbuch");

// AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();

