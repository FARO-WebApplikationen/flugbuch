var f1 = dv.addFooter();
f1.append("CF - Flugbuch");


});