var dv = AppGiniHelper.DV;
dv.getField("kontrollzone").size(50);
dv.getField("flugplatznummer").size(100);
dv.getField("bundesland").size(250);
dv.getField("zvr").size(250);
dv.getField("flughoehe").size(250);
dv.getField("mtom").size(250);

dv.addGroup("1_basisdaten", "Flugplatz - Basisdaten", ["flugplatznummer", "artikel_16", "vereinsname", "bundesland", "webseite", "telefon", "vorname", "nachname", "email", "zvr", "flughoehe", "mtom"], Variation.primary);
dv.addGroup("2_bescheid", "Artikel 16 - Dokumente", ["artikel16", "mfbo", "richtlinie", "flugplatzordnung", "verhaltensregeln", "sonstige_datei"], Variation.info);
dv.addGroup("3_geografie", "Geografische Daten", ["google_map", "open_street_map", "acg_map", "flugbereich"], Variation.info);
dv.addGroup("4_bilder", "Bilder", ["bild1", "bild2", "bild3"], Variation.success);
dv.addGroup("5_anmerkungen", "Anmerkungen, allgemeine Beschreibung", ["kontrollzone", "besonderheit", "beschreibung"], Variation.danger);

var f1 = dv.addFooter();
f1.append("CF - Flugbuch");

new AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();