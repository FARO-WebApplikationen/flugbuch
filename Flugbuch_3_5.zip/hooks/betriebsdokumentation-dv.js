var dv = AppGiniHelper.DV;
dv.getField("nr").size(200);

var f1 = dv.addFooter();
f1.append("CF - Flugbuch");

AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();

// populate curent date time for NEW record
$j(function () {
    // check if data (record) exist or not
    if ($j('#datum').val()) return;
    // populate the current date (using moment.js)
    $j('#datum').val(moment().format('DD.MM.YYYY'));	
	// check if data (record) exist or not
    // if ($j('#beginn').val()) return;
    // populate the current date time (using moment.js)
    // $j('#beginn').val(moment().format('H:mm'));
	// check if data (record) exist or not
	// if ($j('#ende').val()) return;
	// check if data (record) exist or not
	// $j('#ende').val(moment().add(180, 'minutes').format('H:mm'));

});