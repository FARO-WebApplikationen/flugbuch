var dv = AppGiniHelper.DV;
dv.getField("betriebszeit_min").size(200);

var f1 = dv.addFooter();
f1.append("CF - Flugbuch");

AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();


// populate curent date time for NEW record
$j(function () {
    // check if data (record) exist or not
    if ($j('#datum').val()) return;
    // populate the current date (using moment.js)
    $j('#datum').val(moment().format('DD.MM.YYYY'));	

});