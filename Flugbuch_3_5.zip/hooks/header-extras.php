<script src="hooks/AppGiniHelper.min.js"></script>
<script src="hooks/AppGiniHelper.dv.signature.min.js"></script>

<script>
  AppGiniHelper.getCommon()
    .setIcon("plane", "text-danger")
    .setTitle("<b>Flugbuch UAS</b>");

  AppGiniHelper.getCommon().getNavbar().fix();

</script>

<style>
	body{
	background: url("images/hintergrund_flugbuch_old.jpg") no-repeat fixed center center / cover;
	}
</style>


<script>
var navbar = AppGiniHelper.getCommon().getNavbar();

var dropdown = navbar.addDropdown("Info", "question-sign", NavPosition.Right);

// dropdown.addDivider("zum Flugbuch");
dropdown.addLink("Zukunft Modellflugsport", "https://www.modellflugsport.at/", "_help", "_blank");
dropdown.addDivider();
dropdown.addLink("Handbuch", "Handbuch_Flugbuch.pdf", "_help", "_blank");
dropdown.addLink("Schulungsvideo Anwender", "https://youtu.be/1L33JbUNr3g", "_help", "_blank");
dropdown.addLink("Schulungsvideo Administrator", "https://youtu.be/LumDVXn5TR8", "_help", "_blank");
dropdown.addDivider();
dropdown.addLink("Versionsupdate", "https://github.com/FARO-WebApplikationen/flugbuch/", "_help", "_blank");
dropdown.addDivider();
dropdown.addLink("Impressum", "lizenz.html", "_help", "_blank");
</script>






<!-- ******************************************************************************************************
     **************************** ab hier bitte keine Veränderungen vornehmen *****************************
	 ******************************************************************************************************
-->

<?php 
    $page_name = basename($_SERVER['PHP_SELF']);
    if ($page_name == 'membership_profile.php') {
?>

<script>
$j(function() {
	$j('#email').prop('readonly', false);
	$j('#custom1').prop('readonly', true);
	$j('#custom2').prop('readonly', false);
	$j('#custom3').prop('readonly', false);
	$j('#custom4').prop('readonly', false);
})
</script>

<?php
    }
?>



<?php
	include_once(__DIR__ . '/../plugins/messages/app-resources/icon.php');
		