var dv = AppGiniHelper.DV;
// dv.getField("pilot").size(250);
dv.getField("anzahl_fluege").size(150);
dv.getField("anzahl_fluege_120").size(150);
dv.getField("max_flughoehe").size(150);
dv.getField("beginn").size(150);
dv.getField("ende").size(150);

dv.addGroup("1_basisdaten", "Flugbucheintrag", ["pilot", "datum", "beginn", "ende", "anzahl_fluege", "anzahl_fluege_120", "max_flughoehe", "luftraumbeobachter"], Variation.primary);
dv.addGroup("2_flugplatz", "Eintrag anderer Flugplatz", ["flugplatz"], Variation.danger);
dv.addGroup("3_modell", "Eintrag Flugmodell / UAS", ["modell"], Variation.success);
dv.addGroup("4_gastflugpilot", "Eintrag Gastflugpilot", ["name_gastpilot", "reg_nr_gastpilot"], Variation.info);
dv.addGroup("5_vereinsmitglied", "Eintrag anderes Vereinsmitglied", ["name_vereinsmitglied", "reg_nr_vereinsmitglied"], Variation.success);
dv.addGroup("6_anmerkungen", "Anmerkungen, Dateien hochladen", ["besonderheiten", "datei", "datei_1"], Variation.danger);

var f1 = dv.addFooter();
f1.append("CF - Flugbuch");

new AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();
new AppGiniFields(["pilot"]).readonly();

// populate curent date time for NEW record
$j(function () {
    // check if data (record) exist or not
    if ($j('#datum').val()) return;
    // populate the current date (using moment.js)
    $j('#datum').val(moment().format('DD.MM.YYYY'));	
	// check if data (record) exist or not
    if ($j('#beginn').val()) return;
    // populate the current date time (using moment.js)
    $j('#beginn').val(moment().format('H:mm'));
	// check if data (record) exist or not
	if ($j('#ende').val()) return;
	// check if data (record) exist or not
	$j('#ende').val(moment().add(180, 'minutes').format('H:mm'));

});