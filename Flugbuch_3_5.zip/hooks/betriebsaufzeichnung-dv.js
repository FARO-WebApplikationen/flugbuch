

var dv = AppGiniHelper.DV;
dv.getField("anzahl_fluege").size(150);
dv.getField("anzahl_fluege_120").size(150);
dv.getField("beginn").size(150);
dv.getField("ende").size(150);
dv.setTitle('Erfassung von Flugbewegungen - ich habe alle Auflagen des Flugplatzes zur Kenntnis genommen und stimme vollinhaltlich zu !');

var f1 = dv.addFooter();
f1.append("CF - Betriebsaufzeichnung");

new AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();

new AppGiniHelperDVSignature.Pad("unterschrift");




// populate curent date time for NEW record
$j(function () {
    // check if data (record) exist or not
    if ($j('#datum').val()) return;
    // populate the current date (using moment.js)
    $j('#datum').val(moment().format('DD.MM.YYYY'));	
	// check if data (record) exist or not
    if ($j('#beginn').val()) return;
    // populate the current date time (using moment.js)
    $j('#beginn').val(moment().format('H:mm'));
	// check if data (record) exist or not
	if ($j('#ende').val()) return;
	// check if data (record) exist or not
	$j('#ende').val(moment().add(180, 'minutes').format('H:mm'));

});