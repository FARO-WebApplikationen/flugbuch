var dv = AppGiniHelper.DV;
dv.getField("inventarnummer").size(300);
dv.getField("kaufpreis").size(300);
dv.getField("marke").size(300);
dv.getField("kapazitaet").size(300);
dv.getField("zellenanzahl").size(300);

var f1 = dv.addFooter();
f1.append("CF - Flugbuch");

AppGiniFields(["erfasser", "erfasst", "geaendert_von", "geaendert"]).hide();

$j(function () {
    // check if data (record) exist or not
    if ($j('#datum').val()) return;
    // populate the current date (using moment.js)
    $j('#datum').val(moment().format('DD.MM.YYYY'));	

});