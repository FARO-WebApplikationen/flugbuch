<?php
	require(__DIR__ . '/incCommon.php');

	$GLOBALS['page_title'] = $Translation['app documentation'];
	include(__DIR__ . '/incHeader.php');
?>
<div class="page-header"><h1><?php echo APP_TITLE . ' ' . $Translation['app documentation']; ?></h1></div>
<div class="row">
	<div class="col-md-3 col-lg-2" id="toc-section">
		<nav class="hidden-print hidden-xs hidden-sm affix">
			<ul class="nav">
				<li>
					<a href="#content-section"><?php echo APP_TITLE; ?></a>
					<ul class="nav">
						<li>
							<a href="#table-flugbuch_verein">Flugbuch</a>
						</li>
						<li>
							<a href="#table-betriebsaufzeichnung">Betriebsaufzeichnung</a>
						</li>
						<li>
							<a href="#table-flugplaetze_oe">Flugpl&#228;tze</a>
						</li>
						<li>
							<a href="#table-mitgliederverwaltung">Mitgliederverwaltung</a>
						</li>
						<li>
							<a href="#table-vereinsunterlagen">Vereinsunterlagen</a>
						</li>
						<li>
							<a href="#table-betriebsdoku">Betriebsdoku</a>
						</li>
						<li>
							<a href="#table-inventar">Inventar des Vereins</a>
						</li>
					</ul>
				</li>
			</ul>
			<a class="back-to-top" href="#content-section"><?php echo $Translation['back to top']; ?></a>
		</nav>
	</div>

	<div class="col-md-9 col-lg-8" id="content-section">
		<p class="app-documentation" id="app-title">

Die Applikation wurde im Rahmen der Umsetzung der EU-VO 2019/947 entwickelt.

Die F&#252;hrung eines Flugbuches im Rahmen einer Artikel 16 - Genehmigung kann auf verschiedene Varianten erfolgen:
<br><br>
<ul>
<li>Auf analoger Basis - Flugbuch in gedruckter Form / handschriftliche Eintr&#228;ge
<li>Auf digitaler Basis - diese Applikation "Flugbuch OnLine" 
<li>In gemischter Form - analog/digital
</ul><br>
F&#252;r den &#220;berpr&#252;fungsfall durch die Beh&#246;rde m&#252;ssen ALLE Aufzeichnungen l&#252;ckenlos vorhanden sein.<br>

<b>Einsatz der Flugbuch OnLine - Applikation</b><br>
<br>
Der jeweilige Verein / die jeweilige Gruppe betreibt das Flugbuch OnLine im Rahmen des Vereines bzw. Bescheidinhaber einer Artikel 16 Genehmigung in Eigenregie auf einem eigenen Webspace. 
Die Datenverantwortung (Stichwort: DSGVO)ausschlie&#223;lich beim Verein.<br><br>
Wesentliche Eckpunkte / Merkmale:<br>
<ul>
<li>Die "Modellflugpl&#228;tze" k&#246;nnen/m&#252;ssen selbst verwaltet werden. Im weiteren Verlauf ist hier angedacht, die Zustimmung der Vereine einzuholen, damit ihre Daten ver&#246;ffentlicht und zur Verf&#252;gung gestellt werden k&#246;nnen.
<li>Eine Registrierung f&#252;r "Gastflugpiloten" ist m&#246;glich. Diese werden durch der jeweiligen Verein / die jeweilige Gruppe verwaltet.
<li>Die Wartung / Verwaltung liegt beim Verein / bei der Gruppe.
<li>Dem Verein / der Gruppe steht die Applikation mit allen systemtechnischen M&#246;glichkeiten zur Verf&#252;gung (Auswertungen, Datendownload im *.csv-Format, ...).
<li>Die Applikation wird als GNU General Public License ver&#246;ffentlicht.
</ul>   
<br>

		</p>

		<h2 class="table-documentation" id="table-flugbuch_verein">Flugbuch</h2>
		<p class="table-documentation">

<b>Fluchbuch des Vereins</b>
<br>
Dieses Flugbuch wird f&#252;r die Aufzeichnung der Fl&#252;ge auf dem Modellflugplatz/-gel&#228;nde verwendet. Alle Felder sind als KANN-Felder eingerichtet. F&#252;r die Nachvollziehbarkeit wird bei jedem Datensatz ein sogenannter "timestamp" mit gespeichert. Der Erfasser wird mit seinem vollen Namen abgespeichert. Zus&#228;tzlich wird das jeweils letzte Ver&#228;nderungsdatum auch gespeichert - inkl. dem Anwender, der die &#196;nderung vorgenommen hat.

		</p>

		<h2 class="table-documentation" id="table-betriebsaufzeichnung">Betriebsaufzeichnung</h2>
		<p class="table-documentation">

<b>Fluchbuch des Vereins</b>
<br>
Dieses Flugbuch wird f&#252;r die Aufzeichnung der Fl&#252;ge auf dem Modellflugplatz/-gel&#228;nde verwendet. Alle Felder sind als KANN-Felder eingerichtet. F&#252;r die Nachvollziehbarkeit wird bei jedem Datensatz ein sogenannter "timestamp" mit gespeichert. Der Erfasser wird mit seinem vollen Namen abgespeichert. Zus&#228;tzlich wird das jeweils letzte Ver&#228;nderungsdatum auch gespeichert - inkl. dem Anwender, der die &#196;nderung vorgenommen hat.

		</p>

		<h2 class="table-documentation" id="table-flugplaetze_oe">Flugpl&#228;tze</h2>
		<p class="table-documentation">

<b>Modellflugpl&#228;tze in &#214;sterreich</b><br>
In dieser Tabelle werden die Informationen der Modellflugpl&#228;tze in &#214;sterreich verwaltet.

		</p>

		<h2 class="table-documentation" id="table-mitgliederverwaltung">Mitgliederverwaltung</h2>
		<p class="table-documentation">

Relevante Unterlagen des Vereins- und Flugbetriebes. 

		</p>

		<h2 class="table-documentation" id="table-vereinsunterlagen">Vereinsunterlagen</h2>
		<p class="table-documentation">

Relevante Unterlagen des Vereins- und Flugbetriebes. 

		</p>

		<h2 class="table-documentation" id="table-betriebsdoku">Betriebsdoku</h2>
		<p class="table-documentation">

In dieser Tabelle werden die aktuellen Betriebsdokumentationen vorgenommen. 
Das k&#246;nnen Informationen wie z.B. tempor&#228;re Sperren des Modellflugplatzes sein, 
Einladungen f&#252;r Arbeitstage, Terminplanung f&#252;r den Rasebn&#228;herdienst und dgl. mehr. 

		</p>

		<h2 class="table-documentation" id="table-inventar">Inventar des Vereins</h2>
		<p class="table-documentation">

Relevante Unterlagen des Vereins- und Flugbetriebes. 

		</p>

	</div>
</div>

<style>
	body { position: relative; }
	#toc-section ul.nav:nth-child(2) {
		margin-left: 1.5em;
	}
	#content-section { border-left: 1px dotted #ddd; padding-top: 6em; }
	h2.table-documentation, h3.field-documentation { padding-top: 3em; }
	#toc-section li.active { font-weight: bold; }
	#toc-section li:not(.active) { font-weight: normal; }
</style>

<script>
	$j(function() {
		$j('body').scrollspy({ target: '#toc-section', offset: 80 });
	})
</script>

<?php
	include(__DIR__ . '/incFooter.php');
