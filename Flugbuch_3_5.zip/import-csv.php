<?php
	define('PREPEND_PATH', '');
	include_once(__DIR__ . '/lib.php');

	// accept a record as an assoc array, return transformed row ready to insert to table
	$transformFunctions = [
		'flugbuch_verein' => function($data, $options = []) {
			if(isset($data['datum'])) $data['datum'] = guessMySQLDateTime($data['datum']);
			if(isset($data['beginn'])) $data['beginn'] = str_replace(',', '.', str_replace('.', '', $data['beginn']));
			if(isset($data['ende'])) $data['ende'] = str_replace(',', '.', str_replace('.', '', $data['ende']));
			if(isset($data['flugplatz'])) $data['flugplatz'] = pkGivenLookupText($data['flugplatz'], 'flugbuch_verein', 'flugplatz');
			if(isset($data['modell'])) $data['modell'] = pkGivenLookupText($data['modell'], 'flugbuch_verein', 'modell');
			if(isset($data['erfasst'])) $data['erfasst'] = guessMySQLDateTime($data['erfasst']);
			if(isset($data['geaendert'])) $data['geaendert'] = guessMySQLDateTime($data['geaendert']);

			return $data;
		},
		'betriebsaufzeichnung' => function($data, $options = []) {
			if(isset($data['datum'])) $data['datum'] = guessMySQLDateTime($data['datum']);
			if(isset($data['beginn'])) $data['beginn'] = str_replace(',', '.', str_replace('.', '', $data['beginn']));
			if(isset($data['ende'])) $data['ende'] = str_replace(',', '.', str_replace('.', '', $data['ende']));
			if(isset($data['erfasst'])) $data['erfasst'] = guessMySQLDateTime($data['erfasst']);
			if(isset($data['geaendert'])) $data['geaendert'] = guessMySQLDateTime($data['geaendert']);

			return $data;
		},
		'flugplaetze_oe' => function($data, $options = []) {

			return $data;
		},
		'bescheiddokumente' => function($data, $options = []) {
			if(isset($data['gueltigkeit'])) $data['gueltigkeit'] = guessMySQLDateTime($data['gueltigkeit']);

			return $data;
		},
		'mitgliederverwaltung' => function($data, $options = []) {
			if(isset($data['datum'])) $data['datum'] = guessMySQLDateTime($data['datum']);
			if(isset($data['geburtsdatum'])) $data['geburtsdatum'] = guessMySQLDateTime($data['geburtsdatum']);
			if(isset($data['reg_gueltig'])) $data['reg_gueltig'] = guessMySQLDateTime($data['reg_gueltig']);
			if(isset($data['kom_gueltig'])) $data['kom_gueltig'] = guessMySQLDateTime($data['kom_gueltig']);
			if(isset($data['erfasst'])) $data['erfasst'] = guessMySQLDateTime($data['erfasst']);
			if(isset($data['geaendert'])) $data['geaendert'] = guessMySQLDateTime($data['geaendert']);

			return $data;
		},
		'vereinsunterlagen' => function($data, $options = []) {
			if(isset($data['datum'])) $data['datum'] = guessMySQLDateTime($data['datum']);
			if(isset($data['erfasst'])) $data['erfasst'] = guessMySQLDateTime($data['erfasst']);
			if(isset($data['geaendert'])) $data['geaendert'] = guessMySQLDateTime($data['geaendert']);

			return $data;
		},
		'betriebsdoku' => function($data, $options = []) {
			if(isset($data['datum'])) $data['datum'] = guessMySQLDateTime($data['datum']);
			if(isset($data['erfasst'])) $data['erfasst'] = guessMySQLDateTime($data['erfasst']);
			if(isset($data['geaendert'])) $data['geaendert'] = guessMySQLDateTime($data['geaendert']);

			return $data;
		},
		'inventar' => function($data, $options = []) {
			if(isset($data['datum'])) $data['datum'] = guessMySQLDateTime($data['datum']);
			if(isset($data['erfasst'])) $data['erfasst'] = guessMySQLDateTime($data['erfasst']);
			if(isset($data['geaendert'])) $data['geaendert'] = guessMySQLDateTime($data['geaendert']);

			return $data;
		},
		'dokumente' => function($data, $options = []) {
			if(isset($data['gueltig_von'])) $data['gueltig_von'] = guessMySQLDateTime($data['gueltig_von']);
			if(isset($data['gueltig_bis'])) $data['gueltig_bis'] = guessMySQLDateTime($data['gueltig_bis']);

			return $data;
		},
		'modelle' => function($data, $options = []) {
			if(isset($data['kaufdatum'])) $data['kaufdatum'] = guessMySQLDateTime($data['kaufdatum']);
			if(isset($data['erstflugdatum'])) $data['erstflugdatum'] = guessMySQLDateTime($data['erstflugdatum']);

			return $data;
		},
		'checklisten' => function($data, $options = []) {
			if(isset($data['modellname'])) $data['modellname'] = pkGivenLookupText($data['modellname'], 'checklisten', 'modellname');
			if(isset($data['hersteller'])) $data['hersteller'] = thisOr($data['modellname'], pkGivenLookupText($data['hersteller'], 'checklisten', 'hersteller'));
			if(isset($data['modelltyp'])) $data['modelltyp'] = thisOr($data['modellname'], pkGivenLookupText($data['modelltyp'], 'checklisten', 'modelltyp'));

			return $data;
		},
		'akkus' => function($data, $options = []) {
			if(isset($data['kaufdatum'])) $data['kaufdatum'] = guessMySQLDateTime($data['kaufdatum']);

			return $data;
		},
		'modellbetriebszeiten' => function($data, $options = []) {
			if(isset($data['datum'])) $data['datum'] = guessMySQLDateTime($data['datum']);
			if(isset($data['modellname'])) $data['modellname'] = pkGivenLookupText($data['modellname'], 'modellbetriebszeiten', 'modellname');

			return $data;
		},
		'akkubetriebszeiten' => function($data, $options = []) {
			if(isset($data['inventarnummer'])) $data['inventarnummer'] = pkGivenLookupText($data['inventarnummer'], 'akkubetriebszeiten', 'inventarnummer');
			if(isset($data['datum'])) $data['datum'] = guessMySQLDateTime($data['datum']);
			if(isset($data['kaufdatum'])) $data['kaufdatum'] = thisOr($data['inventarnummer'], pkGivenLookupText($data['kaufdatum'], 'akkubetriebszeiten', 'kaufdatum'));
			if(isset($data['marke'])) $data['marke'] = thisOr($data['inventarnummer'], pkGivenLookupText($data['marke'], 'akkubetriebszeiten', 'marke'));
			if(isset($data['kapazitaet'])) $data['kapazitaet'] = thisOr($data['inventarnummer'], pkGivenLookupText($data['kapazitaet'], 'akkubetriebszeiten', 'kapazitaet'));
			if(isset($data['zellenanzahl'])) $data['zellenanzahl'] = thisOr($data['inventarnummer'], pkGivenLookupText($data['zellenanzahl'], 'akkubetriebszeiten', 'zellenanzahl'));

			return $data;
		},
		'ticketsystem' => function($data, $options = []) {

			return $data;
		},
		'schaden' => function($data, $options = []) {

			return $data;
		},
	];

	// accept a record as an assoc array, return a boolean indicating whether to import or skip record
	$filterFunctions = [
		'flugbuch_verein' => function($data, $options = []) { return true; },
		'betriebsaufzeichnung' => function($data, $options = []) { return true; },
		'flugplaetze_oe' => function($data, $options = []) { return true; },
		'bescheiddokumente' => function($data, $options = []) { return true; },
		'mitgliederverwaltung' => function($data, $options = []) { return true; },
		'vereinsunterlagen' => function($data, $options = []) { return true; },
		'betriebsdoku' => function($data, $options = []) { return true; },
		'inventar' => function($data, $options = []) { return true; },
		'dokumente' => function($data, $options = []) { return true; },
		'modelle' => function($data, $options = []) { return true; },
		'checklisten' => function($data, $options = []) { return true; },
		'akkus' => function($data, $options = []) { return true; },
		'modellbetriebszeiten' => function($data, $options = []) { return true; },
		'akkubetriebszeiten' => function($data, $options = []) { return true; },
		'ticketsystem' => function($data, $options = []) { return true; },
		'schaden' => function($data, $options = []) { return true; },
	];

	/*
	Hook file for overwriting/amending $transformFunctions and $filterFunctions:
	hooks/import-csv.php
	If found, it's included below

	The way this works is by either completely overwriting any of the above 2 arrays,
	or, more commonly, overwriting a single function, for example:
		$transformFunctions['tablename'] = function($data, $options = []) {
			// new definition here
			// then you must return transformed data
			return $data;
		};

	Another scenario is transforming a specific field and leaving other fields to the default
	transformation. One possible way of doing this is to store the original transformation function
	in GLOBALS array, calling it inside the custom transformation function, then modifying the
	specific field:
		$GLOBALS['originalTransformationFunction'] = $transformFunctions['tablename'];
		$transformFunctions['tablename'] = function($data, $options = []) {
			$data = call_user_func_array($GLOBALS['originalTransformationFunction'], [$data, $options]);
			$data['fieldname'] = 'transformed value';
			return $data;
		};
	*/

	@include(__DIR__ . '/hooks/import-csv.php');

	$ui = new CSVImportUI($transformFunctions, $filterFunctions);
