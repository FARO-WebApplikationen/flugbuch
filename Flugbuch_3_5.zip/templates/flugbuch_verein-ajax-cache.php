<?php
	$rdata = array_map('to_utf8', array_map('safe_html', array_map('html_attr_tags_ok', $rdata)));
	$jdata = array_map('to_utf8', array_map('safe_html', array_map('html_attr_tags_ok', $jdata)));
?>
<script>
	$j(function() {
		var tn = 'flugbuch_verein';

		/* data for selected record, or defaults if none is selected */
		var data = {
			flugplatz: <?php echo json_encode(['id' => $rdata['flugplatz'], 'value' => $rdata['flugplatz'], 'text' => $jdata['flugplatz']]); ?>,
			modell: <?php echo json_encode(['id' => $rdata['modell'], 'value' => $rdata['modell'], 'text' => $jdata['modell']]); ?>
		};

		/* initialize or continue using AppGini.cache for the current table */
		AppGini.cache = AppGini.cache || {};
		AppGini.cache[tn] = AppGini.cache[tn] || AppGini.ajaxCache();
		var cache = AppGini.cache[tn];

		/* saved value for flugplatz */
		cache.addCheck(function(u, d) {
			if(u != 'ajax_combo.php') return false;
			if(d.t == tn && d.f == 'flugplatz' && d.id == data.flugplatz.id)
				return { results: [ data.flugplatz ], more: false, elapsed: 0.01 };
			return false;
		});

		/* saved value for modell */
		cache.addCheck(function(u, d) {
			if(u != 'ajax_combo.php') return false;
			if(d.t == tn && d.f == 'modell' && d.id == data.modell.id)
				return { results: [ data.modell ], more: false, elapsed: 0.01 };
			return false;
		});

		cache.start();
	});
</script>

