<?php
	$rdata = array_map('to_utf8', array_map('safe_html', array_map('html_attr_tags_ok', $rdata)));
	$jdata = array_map('to_utf8', array_map('safe_html', array_map('html_attr_tags_ok', $jdata)));
?>
<script>
	$j(function() {
		var tn = 'checklisten';

		/* data for selected record, or defaults if none is selected */
		var data = {
			modellname: <?php echo json_encode(['id' => $rdata['modellname'], 'value' => $rdata['modellname'], 'text' => $jdata['modellname']]); ?>,
			hersteller: <?php echo json_encode($jdata['hersteller']); ?>,
			modelltyp: <?php echo json_encode($jdata['modelltyp']); ?>
		};

		/* initialize or continue using AppGini.cache for the current table */
		AppGini.cache = AppGini.cache || {};
		AppGini.cache[tn] = AppGini.cache[tn] || AppGini.ajaxCache();
		var cache = AppGini.cache[tn];

		/* saved value for modellname */
		cache.addCheck(function(u, d) {
			if(u != 'ajax_combo.php') return false;
			if(d.t == tn && d.f == 'modellname' && d.id == data.modellname.id)
				return { results: [ data.modellname ], more: false, elapsed: 0.01 };
			return false;
		});

		/* saved value for modellname autofills */
		cache.addCheck(function(u, d) {
			if(u != tn + '_autofill.php') return false;

			for(var rnd in d) if(rnd.match(/^rnd/)) break;

			if(d.mfk == 'modellname' && d.id == data.modellname.id) {
				$j('#hersteller' + d[rnd]).html(data.hersteller);
				$j('#modelltyp' + d[rnd]).html(data.modelltyp);
				return true;
			}

			return false;
		});

		cache.start();
	});
</script>

